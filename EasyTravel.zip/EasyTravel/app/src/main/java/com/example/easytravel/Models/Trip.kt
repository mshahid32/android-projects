package com.example.easytravel.Models

class Trip {
    var amount: String? = null
    var date: String? = null
    var departure: String? = null
    var duration: String? = null
    var time: String? = null
    var tripName: String? = null
    var description: String? = null

    constructor() {}
}
