package com.example.easytravel.Models

class Buses {
    var busNo: String? = null
    var points : String? = null
    var departure : String? = null

    constructor() {}

}