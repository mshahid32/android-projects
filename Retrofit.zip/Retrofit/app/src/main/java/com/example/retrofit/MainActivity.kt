package com.example.retrofit

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.retrofit.Adapters.DataAdapter
import com.example.retrofit.Api.ApiInterface
import com.example.retrofit.Api.RetrofitHelper
import com.example.retrofit.Models.MyData
import com.example.retrofit.Repository.MainRepository
import com.example.retrofit.ViewModels.MainViewModel
import com.example.retrofit.ViewModels.MainViewModelFactory
import com.example.retrofit.databinding.ActivityMainBinding
import retrofit2.create

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding
    lateinit var mainViewModel: MainViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val apiInterface = RetrofitHelper.getInstance().create(ApiInterface::class.java)
        val repository = MainRepository(apiInterface)
        mainViewModel= ViewModelProvider(this,MainViewModelFactory(repository)).get(MainViewModel::class.java)
        mainViewModel.MyDataItem().observe(this, Observer{
            binding.mydataRecycler.layoutManager = LinearLayoutManager(this)
            binding.mydataRecycler.adapter = DataAdapter(it)
        })

    }
}