package com.example.retrofit.Api

import com.example.retrofit.Models.MyData
import retrofit2.Call
import retrofit2.http.GET

interface ApiInterface {

    @GET("posts")
    fun getData(): Call<ArrayList<MyData>>
}