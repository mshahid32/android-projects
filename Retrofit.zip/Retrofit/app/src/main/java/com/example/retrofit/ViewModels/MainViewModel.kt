package com.example.retrofit.ViewModels

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.retrofit.Adapters.DataAdapter
import com.example.retrofit.Models.MyData
import com.example.retrofit.Repository.MainRepository
import com.google.gson.JsonObject

class MainViewModel(private val repository: MainRepository) : ViewModel() {
    fun MyDataItem():MutableLiveData<ArrayList<MyData>>{
        return repository.getData()
    }
}