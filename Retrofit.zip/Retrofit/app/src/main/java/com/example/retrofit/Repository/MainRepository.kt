package com.example.retrofit.Repository

import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.example.retrofit.Api.ApiInterface
import com.example.retrofit.Models.MyData
import com.google.gson.JsonObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainRepository(private val apiInterface: ApiInterface) {


    fun getData(): MutableLiveData<ArrayList<MyData>> {
        val result = apiInterface.getData()
        val loginLiveData = MutableLiveData<ArrayList<MyData>>()
        result.enqueue(object : Callback<ArrayList<MyData>?> {
            override fun onResponse(
                call: Call<ArrayList<MyData>?>,
                response: Response<ArrayList<MyData>?>
            ) {
                val responseBody = response.body()!!
                loginLiveData.postValue(responseBody)

            }

            override fun onFailure(call: Call<ArrayList<MyData>?>, t: Throwable) {
                TODO("Not yet implemented")
            }

        })

        return loginLiveData

    }
}