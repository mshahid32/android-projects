package com.example.retrofit.Models

data class MyData(
    var userId:String,
    var id:String,
    var title:String,
    var body:String
)
