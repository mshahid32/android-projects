package com.example.retrofit.Repository

import android.util.Log
import android.widget.Toast
import androidx.lifecycle.MutableLiveData
import com.example.retrofit.Api.ApiInterface
import com.example.retrofit.Models.MyData
import com.google.gson.JsonObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import javax.inject.Inject

class MainRepository @Inject constructor(private val apiInterface: ApiInterface) {

    fun getData(): MutableLiveData<ArrayList<MyData>> {
        val result = apiInterface.getData()
        val loginLiveData = MutableLiveData<ArrayList<MyData>>()
        result.enqueue(object : Callback<ArrayList<MyData>?> {
            override fun onResponse(
                call: Call<ArrayList<MyData>?>,
                response: Response<ArrayList<MyData>?>
            ) {
                val responseBody = response.body()!!
                loginLiveData.postValue(responseBody)
            }

            override fun onFailure(call: Call<ArrayList<MyData>?>, t: Throwable) {
               Log.d("Error","Api Not Response")
            }
        })
        return loginLiveData
    }
    fun getCommentsById(postId : Int) : MutableLiveData<ArrayList<MyData>>{
        val result = apiInterface.getCommentsById(postId)
        val commentLiveData = MutableLiveData<ArrayList<MyData>>()
        result.enqueue(object : Callback<ArrayList<MyData>?> {
            override fun onResponse(
                call: Call<ArrayList<MyData>?>,
                response: Response<ArrayList<MyData>?>
            ) {
                val responseBody = response.body()!!
                commentLiveData.postValue(responseBody)
            }

            override fun onFailure(call: Call<ArrayList<MyData>?>, t: Throwable) {
                Log.d("Error","Api Not Response")
            }
        })
        return commentLiveData
    }

    fun getPost(postId: Int) : MutableLiveData<MyData>{
        val result = apiInterface.getPost(postId)
        val postLiveData = MutableLiveData<MyData>()
        result.enqueue(object : Callback<MyData> {
            override fun onResponse(
                call: Call<MyData>,
                response: Response<MyData>
            ) {
                val responseBody = response.body()!!
                postLiveData.postValue(responseBody)
            }

            override fun onFailure(call: Call<MyData>, t: Throwable) {
                Log.d("Error",t.message.toString())
            }
        })
        return postLiveData
    }
}