package com.example.retrofit.Api

import com.example.retrofit.Models.MyData
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiInterface {

    @GET("posts")
    fun getData(): Call<ArrayList<MyData>>

    @GET("comments")
    fun getCommentsById(@Query("postId") postId : Int):Call<ArrayList<MyData>>

    @GET("posts/{id}")
    fun getPost(@Path("id") postId: Int) : Call<MyData>
}