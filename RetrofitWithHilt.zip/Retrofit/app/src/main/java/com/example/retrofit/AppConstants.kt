package com.example.retrofit

class AppConstants {
    companion object {
        var BASE_URL: String = "https://jsonplaceholder.typicode.com/"
    }
}