package com.example.yows.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.yows.R
import com.example.yows.models.FoodDetail
import com.example.yows.models.MenuDetail
import com.squareup.picasso.Picasso

class MenuDetailAdapter(private var list: ArrayList<MenuDetail>) : RecyclerView.Adapter<MenuDetailAdapter.ViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.restourant_menu_scroll_layout, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val menuRecord = list[position]
        holder.label.text = menuRecord.label
        holder.time.text = menuRecord.time
        holder.resName.text = menuRecord.restaurantName
        holder.rating.text = menuRecord.rating
        holder.totalRating.text = menuRecord.TotalRate
        holder.resType.text = menuRecord.restaurantType
        holder.resCategory.text = menuRecord.restaurantCategory
        holder.price.text = menuRecord.price
        Picasso.get().load(menuRecord.image).error(R.mipmap.ic_launcher).into(holder.image)
    }

    override fun getItemCount(): Int {
       return list.size
    }
    class ViewHolder (itemView: android.view.View) : RecyclerView.ViewHolder(itemView){
        val label : TextView = itemView.findViewById(R.id.tvLabel)
        val time : TextView = itemView.findViewById(R.id.tvTime)
        val resName : TextView = itemView.findViewById(R.id.tvResName)
        val rating : TextView = itemView.findViewById(R.id.tvRating)
        val totalRating : TextView = itemView.findViewById(R.id.tvTotalRating)
        val resType : TextView = itemView.findViewById(R.id.tvRestaurantType)
        val resCategory : TextView = itemView.findViewById(R.id.tvResCategory)
        val price : TextView = itemView.findViewById(R.id.tvPrice)
        var image : ImageView = itemView.findViewById(R.id.imgMenu)
    }
}