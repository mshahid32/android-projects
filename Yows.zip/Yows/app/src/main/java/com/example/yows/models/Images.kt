package com.example.yows.models

data class Images(val image : String)
