package com.example.yows

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.yows.adapters.ImageRecyclerAdapter
import com.example.yows.adapters.MenuCategoryAdapter
import com.example.yows.databinding.ActivityRestourantMenuBinding
import com.example.yows.models.*
import org.json.JSONArray
import org.json.JSONException
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStream
import java.io.InputStreamReader

class RestourantMenuActivity : AppCompatActivity() {
    private lateinit var binding : ActivityRestourantMenuBinding
    private  var viewItems = ArrayList<Images>()
    private var menuCategory = ArrayList<MenuCategory>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRestourantMenuBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.include.imgback.setOnClickListener {
            startActivity(Intent(this@RestourantMenuActivity,MainActivity::class.java))
        }

        addItemsFromJSON()
        binding.myRecycler.setHasFixedSize(true)

        binding.myRecycler.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL,false)
        binding.myRecycler.adapter = ImageRecyclerAdapter(viewItems)

        addMenuFromJSON()
        binding.myMenuRecycler.setHasFixedSize(true)
        binding.myMenuRecycler.layoutManager =   LinearLayoutManager(this)
        binding.myMenuRecycler.adapter = MenuCategoryAdapter(menuCategory)
    }
    private fun addItemsFromJSON() {
        try {
            val jsonDataString = readJSONDataFromFile()
            val jsonArray = JSONArray(jsonDataString)
            for (i in 0 until jsonArray.length()) {
                val itemObj = jsonArray.getJSONObject(i)
                val image = itemObj.getString("images")
                viewItems.add(Images(image))
            }
        } catch (e: JSONException) {
            Log.d("Error", "addItemsFromJSON: ", e)
        } catch (e: IOException) {
            Log.d("Error", "addItemsFromJSON: ", e)
        }
    }

    @Throws(IOException::class)
    private fun readJSONDataFromFile(): String {
        var inputStream: InputStream? = null
        val builder = StringBuilder()
        try {
            var jsonString: String?
            inputStream = resources.openRawResource(R.raw.images)
            val bufferedReader = BufferedReader(
                InputStreamReader(inputStream, "UTF-8")
            )
            while (bufferedReader.readLine().also { jsonString = it } != null) {
                builder.append(jsonString)
            }
        } finally {
            if (inputStream != null) {
                inputStream.close()
            }
        }
        return String(builder)
    }


    private fun addMenuFromJSON() {
        try {
            val jsonDataString = readMenuDataFromFile()
            val jsonArray = JSONArray(jsonDataString)
            for (i in 0 until jsonArray.length()) {
                var menuItems = ArrayList<MenuDetail>()
                val itemObj = jsonArray.getJSONObject(i)
                val menuCategoryName = itemObj.getString("menuCategoryName")
                val foodList = itemObj.getJSONArray("menuList")
                for (j in 0 until foodList.length()){
                    val foodDetail = foodList.getJSONObject(j)
                    val label = foodDetail.getString("label")
                    val favourite = foodDetail.getString("favourite")
                    val time = foodDetail.getString("time")
                    val restaurantName = foodDetail.getString("restaurantName")
                    val rating = foodDetail.getString("rating")
                    val totalRate = foodDetail.getString("TotalRate")
                    val restaurantType = foodDetail.getString("restaurantType")
                    val restaurantCategory = foodDetail.getString("restaurantCategory")
                    val price = foodDetail.getString("price")
                    val image = foodDetail.getString("image")
                    menuItems.add(MenuDetail(label, favourite,time,restaurantName,rating,totalRate,restaurantType,restaurantCategory,
                        price,image))
                }
                menuCategory.add(MenuCategory(menuCategoryName,menuItems))
                //viewItems.clear()

            }
        } catch (e: JSONException) {
            Log.d("Error", "addItemsFromJSON: ", e)
        } catch (e: IOException) {
            Log.d("Error", "addItemsFromJSON: ", e)
        }
    }

    @Throws(IOException::class)
    private fun readMenuDataFromFile(): String {
        var inputStream: InputStream? = null
        val builder = StringBuilder()
        try {
            var jsonString: String?
            inputStream = resources.openRawResource(R.raw.menu)
            val bufferedReader = BufferedReader(
                InputStreamReader(inputStream, "UTF-8")
            )
            while (bufferedReader.readLine().also { jsonString = it } != null) {
                builder.append(jsonString)
            }
        } finally {
            if (inputStream != null) {
                inputStream.close()
            }
        }
        return String(builder)
    }
}