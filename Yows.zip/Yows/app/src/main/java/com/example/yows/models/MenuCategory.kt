package com.example.yows.models

data class MenuCategory(val menuCategoryName : String,val menuList : ArrayList<MenuDetail>) {
}