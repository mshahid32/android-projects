package com.example.yows.models

data class FoodDetail (
    var name: String,
    var detail : String,
    var discountPrice : String,
    var price : String,
    var image : String){
}