package com.example.yows.models

data class FoodCategory(val categoryName : String,val foodList : ArrayList<FoodDetail> ) {

}