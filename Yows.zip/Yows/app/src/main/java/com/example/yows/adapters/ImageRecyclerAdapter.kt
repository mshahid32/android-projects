package com.example.yows.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.yows.R
import com.example.yows.models.Images
import com.squareup.picasso.Picasso

class ImageRecyclerAdapter(private var list: ArrayList<Images>) : RecyclerView.Adapter<ImageRecyclerAdapter.ViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ImageRecyclerAdapter.ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.images_recycler_layout, parent, false)
        return ImageRecyclerAdapter.ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ImageRecyclerAdapter.ViewHolder, position: Int) {
        val imgList = list[position]
        Picasso.get().load(imgList.image).error(R.mipmap.ic_launcher).into(holder.images)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    class ViewHolder(itemView: android.view.View) : RecyclerView.ViewHolder(itemView) {
        val images: ImageView = itemView.findViewById(R.id.imgScroll)
    }
}