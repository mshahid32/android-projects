package com.example.yows.models

data class MenuDetail (
    var label: String,
    var favourite : String,
    var time : String,
    var restaurantName : String,
    var rating : String,
    var TotalRate: String,
    var restaurantType : String,
    var restaurantCategory : String,
    var price : String,
    var image : String){
}