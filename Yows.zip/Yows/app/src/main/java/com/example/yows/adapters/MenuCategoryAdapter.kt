package com.example.yows.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.yows.R
import com.example.yows.models.FoodCategory
import com.example.yows.models.MenuCategory

class MenuCategoryAdapter(private var list: ArrayList<MenuCategory>) : RecyclerView.Adapter<MenuCategoryAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MenuCategoryAdapter.ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.show_menu_category, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: MenuCategoryAdapter.ViewHolder, position: Int) {
        val category = list[position]
        holder.categoryName.text = category.menuCategoryName
        val layoutManager = LinearLayoutManager(
            holder.rvMenuDetail.getContext(),
            LinearLayoutManager.HORIZONTAL,
            false
        )
        holder.rvMenuDetail.layoutManager = layoutManager
        holder.rvMenuDetail.adapter = MenuDetailAdapter(category.menuList!!)
    }

    override fun getItemCount(): Int {
        return list.size
    }
    class ViewHolder(itemView: android.view.View) : RecyclerView.ViewHolder(itemView) {
        val categoryName: TextView = itemView.findViewById(R.id.tvMenuCategoryName)
        val rvMenuDetail : RecyclerView = itemView.findViewById(R.id.rv_menu_category)
    }
}